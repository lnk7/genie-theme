<?php

namespace CoteAtHome\Releases;

use CoteAtHome\Abstracts\Release;

/**
 * Class clean
 *
 * @package CoteAtHome\Releases
 */
class EnsureOnceUsage extends Release
{

    /**
     * perform some maintenance during deployment
     */
    public static function run()
    {
        global $wpdb;
        $wpdb->query("update $wpdb->postmeta set meta_value = 1 where meta_key = 'usage_limit' and post_id in (select ID from wp_posts where post_type = 'shop_coupon') ");
        $wpdb->query("update $wpdb->postmeta set meta_value = 0 where meta_key = 'usage_count' and post_id in (select ID from wp_posts where post_type = 'shop_coupon') ");

        return "Coupons usage updated ";
    }

}