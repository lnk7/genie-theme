<?php

namespace CoteAtHome\Releases;

use CoteAtHome\Abstracts\Release;
use CoteAtHome\Objects\GiftCard;

/**
 * Class clean
 *
 * @package CoteAtHome\Releases
 */
class UpdateAllCoupons extends Release
{


    public static $runOnce = true;


    /**
     * perform some maintenance during deployment
     */
    public static function run()
    {

        global $wpdb;

        $results = $wpdb->get_results("select ID from wp_posts where post_type='shop_coupon' ");
        foreach($results as $result) {
            update_field('field_coupon_customers', 'all', $result->ID);
        }

        return "All Coupons updated to 'any' ";
    }

}