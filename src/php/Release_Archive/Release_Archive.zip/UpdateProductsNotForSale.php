<?php

namespace CoteAtHome\Releases;

use CoteAtHome\Abstracts\Release;

/**
 * Class clean
 *
 * @package CoteAtHome\Releases
 */
class UpdateProductsNotForSale extends Release
{


    public static $runOnce = true;


    /**
     * perform some maintenance during deployment
     */
    public static function run()
    {

        $products = wc_get_products([
            'numberposts' => -1,
            'post_status' => 'any',
        ]);

        foreach($products as $product) {

            $notForSale = get_field('not_for_sale', $product->get_id());
            if (!$notForSale ) {
                update_field('not_for_sale', 0, $product->get_id());
            }

        }

        return "Products Updated";
    }

}