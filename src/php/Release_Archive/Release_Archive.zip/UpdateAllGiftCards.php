<?php

namespace CoteAtHome\Releases;

use CoteAtHome\Abstracts\Release;
use CoteAtHome\Objects\GiftCard;

/**
 * Class clean
 *
 * @package CoteAtHome\Releases
 */
class UpdateAllGiftCards extends Release
{


    public static $runOnce = true;


    /**
     * perform some maintenance during deployment
     */
    public static function run()
    {

        $cards = GiftCard::get();
        foreach($cards as $card) {
            $card->type = GiftCard::toggleCard;
            $card->save();
        }

        return "All Gift Cards updated excluded";
    }

}