<?php

namespace CoteAtHome\Releases;

use CoteAtHome\Abstracts\Release;

/**
 * Class clean
 *
 * @package CoteAtHome\Releases
 */
class BookingSlotExcludes extends Release
{


    public static $runOnce = true;


    /**
     * perform some maintenance during deployment
     */
    public static function run()
    {

        global $wpdb;

        $results = $wpdb->get_results("SELECT ID FROM wp_posts WHERE post_title LIKE 'BS-%' AND post_type = 'shop_coupon' ");

        foreach ($results as $result) {
            update_field('field_coupon_exclude_from_count', 1, $result->ID);
        }

        return "Booking Coupons excluded";
    }

}