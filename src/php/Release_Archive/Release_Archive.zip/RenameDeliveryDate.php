<?php

namespace CoteAtHome\Releases;

use CoteAtHome\Abstracts\Release;

/**
 * Class clean
 *
 * @package CoteAtHome\Releases
 */
class RenameDeliveryDate extends Release
{


    public static $runOnce = true;


    /**
     * perform some maintenance during deployment
     */
    public static function run()
    {

        global $wpdb;
        $wpdb->query("delete from wp_posts WHERE post_type = 'date'");
        $wpdb->query("UPDATE wp_posts SET post_type = 'date' WHERE post_type = 'delivery-date'");
        return "Delivery Date Post Type Renamed";
    }

}