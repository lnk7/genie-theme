<?php

namespace CoteAtHome\Releases;

use CoteAtHome\Abstracts\Release;
use CoteAtHome\Objects\Event;

/**
 * Class clean
 *
 * @package CoteAtHome\Releases
 */
class UpdateEventsToConfirmed extends Release
{


    public static $runOnce = true;


    /**
     * perform some maintenance during deployment
     */
    public static function run()
    {

        $events = Event::get();
        foreach($events as $event) {
            $event->confirmed = true;
            $event->save();
        }

        return "Events Updated excluded";
    }

}