<?php

namespace CoteAtHome\Releases;

use CoteAtHome\Abstracts\Release;
use CoteAtHome\Objects\Product;
use CoteAtHome\Objects\ProductComponent;

/**
 * Class clean
 *
 * @package CoteAtHome\Releases
 */
class CreateNotForSaleProducts extends Release
{


    public static $runOnce = true;


    static $components = 'a:22:{s:13:"demi-baguette";a:2:{i:0;a:2:{s:4:"slug";s:31:"not-for-sale-demi-baguette-125g";s:8:"quantity";s:1:"1";}i:1;a:2:{s:4:"slug";s:49:"not-for-sale-beurre-demi-sel-aop-charentes-poitou";s:8:"quantity";s:1:"1";}}s:49:"lamb-parmentier-set-menu-la-place-sauvignon-blanc";a:6:{i:0;a:2:{s:4:"slug";s:21:"chicken-liver-parfait";s:8:"quantity";s:1:"2";}i:1;a:2:{s:4:"slug";s:31:"not-for-sale-demi-baguette-125g";s:8:"quantity";s:1:"1";}i:2;a:2:{s:4:"slug";s:15:"lamb-parmentier";s:8:"quantity";s:1:"1";}i:3;a:2:{s:4:"slug";s:11:"minted-peas";s:8:"quantity";s:1:"1";}i:4;a:2:{s:4:"slug";s:13:"creme-caramel";s:8:"quantity";s:1:"2";}i:5;a:2:{s:4:"slug";s:24:"sauvignon-blanc-la-place";s:8:"quantity";s:1:"1";}}s:31:"lamb-parmentier-set-menu-merlot";a:6:{i:0;a:2:{s:4:"slug";s:21:"chicken-liver-parfait";s:8:"quantity";s:1:"2";}i:1;a:2:{s:4:"slug";s:31:"not-for-sale-demi-baguette-125g";s:8:"quantity";s:1:"1";}i:2;a:2:{s:4:"slug";s:15:"lamb-parmentier";s:8:"quantity";s:1:"1";}i:3;a:2:{s:4:"slug";s:11:"minted-peas";s:8:"quantity";s:1:"1";}i:4;a:2:{s:4:"slug";s:13:"creme-caramel";s:8:"quantity";s:1:"2";}i:5;a:2:{s:4:"slug";s:26:"merlot-chemin-de-marquiere";s:8:"quantity";s:1:"1";}}s:29:"lamb-parmentier-set-menu-none";a:5:{i:0;a:2:{s:4:"slug";s:21:"chicken-liver-parfait";s:8:"quantity";s:1:"2";}i:1;a:2:{s:4:"slug";s:31:"not-for-sale-demi-baguette-125g";s:8:"quantity";s:1:"1";}i:2;a:2:{s:4:"slug";s:15:"lamb-parmentier";s:8:"quantity";s:1:"1";}i:3;a:2:{s:4:"slug";s:11:"minted-peas";s:8:"quantity";s:1:"1";}i:4;a:2:{s:4:"slug";s:13:"creme-caramel";s:8:"quantity";s:1:"2";}}s:47:"poulet-grille-set-menu-la-place-sauvignon-blanc";a:7:{i:0;a:2:{s:4:"slug";s:14:"pork-rillettes";s:8:"quantity";s:1:"2";}i:1;a:2:{s:4:"slug";s:31:"not-for-sale-demi-baguette-125g";s:8:"quantity";s:1:"1";}i:2;a:2:{s:4:"slug";s:13:"poulet-grille";s:8:"quantity";s:1:"1";}i:3;a:2:{s:4:"slug";s:12:"french-beans";s:8:"quantity";s:1:"1";}i:4;a:2:{s:4:"slug";s:13:"creme-caramel";s:8:"quantity";s:1:"2";}i:5;a:2:{s:4:"slug";s:13:"gratin-potato";s:8:"quantity";s:1:"1";}i:6;a:2:{s:4:"slug";s:24:"sauvignon-blanc-la-place";s:8:"quantity";s:1:"1";}}s:29:"poulet-grille-set-menu-merlot";a:7:{i:0;a:2:{s:4:"slug";s:14:"pork-rillettes";s:8:"quantity";s:1:"2";}i:1;a:2:{s:4:"slug";s:31:"not-for-sale-demi-baguette-125g";s:8:"quantity";s:1:"1";}i:2;a:2:{s:4:"slug";s:13:"poulet-grille";s:8:"quantity";s:1:"1";}i:3;a:2:{s:4:"slug";s:12:"french-beans";s:8:"quantity";s:1:"1";}i:4;a:2:{s:4:"slug";s:13:"creme-caramel";s:8:"quantity";s:1:"2";}i:5;a:2:{s:4:"slug";s:13:"gratin-potato";s:8:"quantity";s:1:"1";}i:6;a:2:{s:4:"slug";s:26:"merlot-chemin-de-marquiere";s:8:"quantity";s:1:"1";}}s:27:"poulet-grille-set-menu-none";a:6:{i:0;a:2:{s:4:"slug";s:14:"pork-rillettes";s:8:"quantity";s:1:"2";}i:1;a:2:{s:4:"slug";s:31:"not-for-sale-demi-baguette-125g";s:8:"quantity";s:1:"1";}i:2;a:2:{s:4:"slug";s:13:"poulet-grille";s:8:"quantity";s:1:"1";}i:3;a:2:{s:4:"slug";s:12:"french-beans";s:8:"quantity";s:1:"1";}i:4;a:2:{s:4:"slug";s:13:"creme-caramel";s:8:"quantity";s:1:"2";}i:5;a:2:{s:4:"slug";s:13:"gratin-potato";s:8:"quantity";s:1:"1";}}s:70:"vegetarian-sausages-with-puy-lentils-set-menu-la-place-sauvignon-blanc";a:6:{i:0;a:2:{s:4:"slug";s:27:"marinated-heritage-beetroot";s:8:"quantity";s:1:"1";}i:1;a:2:{s:4:"slug";s:31:"not-for-sale-demi-baguette-125g";s:8:"quantity";s:1:"1";}i:2;a:2:{s:4:"slug";s:36:"vegetarian-sausages-with-puy-lentils";s:8:"quantity";s:1:"1";}i:3;a:2:{s:4:"slug";s:24:"ratatouille-with-spinach";s:8:"quantity";s:1:"1";}i:4;a:2:{s:4:"slug";s:12:"lemon-posset";s:8:"quantity";s:1:"2";}i:5;a:2:{s:4:"slug";s:24:"sauvignon-blanc-la-place";s:8:"quantity";s:1:"1";}}s:52:"vegetarian-sausages-with-puy-lentils-set-menu-merlot";a:6:{i:0;a:2:{s:4:"slug";s:27:"marinated-heritage-beetroot";s:8:"quantity";s:1:"1";}i:1;a:2:{s:4:"slug";s:31:"not-for-sale-demi-baguette-125g";s:8:"quantity";s:1:"1";}i:2;a:2:{s:4:"slug";s:36:"vegetarian-sausages-with-puy-lentils";s:8:"quantity";s:1:"1";}i:3;a:2:{s:4:"slug";s:24:"ratatouille-with-spinach";s:8:"quantity";s:1:"1";}i:4;a:2:{s:4:"slug";s:12:"lemon-posset";s:8:"quantity";s:1:"2";}i:5;a:2:{s:4:"slug";s:26:"merlot-chemin-de-marquiere";s:8:"quantity";s:1:"1";}}s:61:"salmon-and-haddock-fishcake-set-menu-la-place-sauvignon-blanc";a:7:{i:0;a:2:{s:4:"slug";s:25:"smoked-mackerel-rillettes";s:8:"quantity";s:1:"1";}i:1;a:2:{s:4:"slug";s:31:"not-for-sale-demi-baguette-125g";s:8:"quantity";s:1:"1";}i:2;a:2:{s:4:"slug";s:27:"haddock-and-salmon-fishcake";s:8:"quantity";s:1:"1";}i:3;a:2:{s:4:"slug";s:6:"frites";s:8:"quantity";s:1:"1";}i:4;a:2:{s:4:"slug";s:11:"minted-peas";s:8:"quantity";s:1:"1";}i:5;a:2:{s:4:"slug";s:16:"chocolate-mousse";s:8:"quantity";s:1:"2";}i:6;a:2:{s:4:"slug";s:24:"sauvignon-blanc-la-place";s:8:"quantity";s:1:"1";}}s:43:"salmon-and-haddock-fishcake-set-menu-merlot";a:7:{i:0;a:2:{s:4:"slug";s:25:"smoked-mackerel-rillettes";s:8:"quantity";s:1:"1";}i:1;a:2:{s:4:"slug";s:31:"not-for-sale-demi-baguette-125g";s:8:"quantity";s:1:"1";}i:2;a:2:{s:4:"slug";s:27:"haddock-and-salmon-fishcake";s:8:"quantity";s:1:"1";}i:3;a:2:{s:4:"slug";s:6:"frites";s:8:"quantity";s:1:"1";}i:4;a:2:{s:4:"slug";s:11:"minted-peas";s:8:"quantity";s:1:"1";}i:5;a:2:{s:4:"slug";s:16:"chocolate-mousse";s:8:"quantity";s:1:"2";}i:6;a:2:{s:4:"slug";s:26:"merlot-chemin-de-marquiere";s:8:"quantity";s:1:"1";}}s:41:"salmon-and-haddock-fishcake-set-menu-none";a:6:{i:0;a:2:{s:4:"slug";s:25:"smoked-mackerel-rillettes";s:8:"quantity";s:1:"1";}i:1;a:2:{s:4:"slug";s:31:"not-for-sale-demi-baguette-125g";s:8:"quantity";s:1:"1";}i:2;a:2:{s:4:"slug";s:27:"haddock-and-salmon-fishcake";s:8:"quantity";s:1:"1";}i:3;a:2:{s:4:"slug";s:6:"frites";s:8:"quantity";s:1:"1";}i:4;a:2:{s:4:"slug";s:11:"minted-peas";s:8:"quantity";s:1:"1";}i:5;a:2:{s:4:"slug";s:16:"chocolate-mousse";s:8:"quantity";s:1:"2";}}s:36:"breaded-chicken-with-fennel-set-menu";a:5:{i:0;a:2:{s:4:"slug";s:31:"not-for-sale-demi-baguette-125g";s:8:"quantity";s:1:"1";}i:1;a:2:{s:4:"slug";s:25:"smoked-mackerel-rillettes";s:8:"quantity";s:1:"1";}i:2;a:2:{s:4:"slug";s:27:"breaded-chicken-with-fennel";s:8:"quantity";s:1:"1";}i:3;a:2:{s:4:"slug";s:25:"not-for-sale-fennel-salad";s:8:"quantity";s:1:"1";}i:4;a:2:{s:4:"slug";s:15:"fine-apple-tart";s:8:"quantity";s:1:"1";}}s:23:"lamb-brochette-set-menu";a:4:{i:0;a:2:{s:4:"slug";s:8:"fougasse";s:8:"quantity";s:1:"1";}i:1;a:2:{s:4:"slug";s:25:"piquant-mixed-olives-120g";s:8:"quantity";s:1:"1";}i:2;a:2:{s:4:"slug";s:27:"chargrilled-lamb-brochettes";s:8:"quantity";s:1:"1";}i:3;a:2:{s:4:"slug";s:13:"creme-caramel";s:8:"quantity";s:1:"1";}}s:22:"poulet-breton-set-menu";a:5:{i:0;a:2:{s:4:"slug";s:31:"not-for-sale-demi-baguette-125g";s:8:"quantity";s:1:"1";}i:1;a:2:{s:4:"slug";s:14:"pork-rillettes";s:8:"quantity";s:1:"1";}i:2;a:2:{s:4:"slug";s:13:"poulet-breton";s:8:"quantity";s:1:"1";}i:3;a:2:{s:4:"slug";s:27:"not-for-sale-frites-for-one";s:8:"quantity";s:1:"1";}i:4;a:2:{s:4:"slug";s:16:"chocolate-mousse";s:8:"quantity";s:1:"1";}}s:27:"salmon-ratatouille-set-menu";a:4:{i:0;a:2:{s:4:"slug";s:31:"not-for-sale-demi-baguette-125g";s:8:"quantity";s:1:"1";}i:1;a:2:{s:4:"slug";s:21:"chicken-liver-parfait";s:8:"quantity";s:1:"1";}i:2;a:2:{s:4:"slug";s:23:"salmon-with-ratatouille";s:8:"quantity";s:1:"1";}i:3;a:2:{s:4:"slug";s:16:"chocolate-mousse";s:8:"quantity";s:1:"1";}}s:27:"breaded-chicken-with-fennel";a:2:{i:0;a:2:{s:4:"slug";s:40:"not-for-sale-breaded-chicken-with-fennel";s:8:"quantity";s:1:"1";}i:1;a:2:{s:4:"slug";s:25:"not-for-sale-fennel-salad";s:8:"quantity";s:1:"1";}}s:13:"poulet-breton";a:2:{i:0;a:2:{s:4:"slug";s:26:"not-for-sale-poulet-breton";s:8:"quantity";s:1:"1";}i:1;a:2:{s:4:"slug";s:27:"not-for-sale-frites-for-one";s:8:"quantity";s:1:"1";}}s:27:"haddock-and-salmon-fishcake";a:2:{i:0;a:2:{s:4:"slug";s:48:"not-for-sale-smoked-haddock-and-salmon-fishcakes";s:8:"quantity";s:1:"1";}i:1;a:2:{s:4:"slug";s:11:"minted-peas";s:8:"quantity";s:1:"1";}}s:13:"poulet-grille";a:2:{i:0;a:2:{s:4:"slug";s:26:"not-for-sale-poulet-grille";s:8:"quantity";s:1:"1";}i:1;a:2:{s:4:"slug";s:13:"gratin-potato";s:8:"quantity";s:1:"1";}}s:50:"vegetarian-sausages-with-puy-lentils-set-menu-none";a:5:{i:0;a:2:{s:4:"slug";s:27:"marinated-heritage-beetroot";s:8:"quantity";s:1:"1";}i:1;a:2:{s:4:"slug";s:31:"not-for-sale-demi-baguette-125g";s:8:"quantity";s:1:"1";}i:2;a:2:{s:4:"slug";s:36:"vegetarian-sausages-with-puy-lentils";s:8:"quantity";s:1:"1";}i:3;a:2:{s:4:"slug";s:24:"ratatouille-with-spinach";s:8:"quantity";s:1:"1";}i:4;a:2:{s:4:"slug";s:12:"lemon-posset";s:8:"quantity";s:1:"2";}}s:16:"beef-bourguignon";a:2:{i:0;a:2:{s:4:"slug";s:18:"beef-bourguignon-2";s:8:"quantity";s:1:"1";}i:1;a:2:{s:4:"slug";s:12:"potato-puree";s:8:"quantity";s:1:"1";}}}';


    static $products = [
        'Beef Bourguignon',
        'Beurre Demi-Sel AOP Charentes-Poitou',
        'Breaded Chicken with Fennel',
        'Chicken and Walnut Salad',
        'Demi Baguette (125g)',
        'Fennel Salad',
        'Frites (for one)',
        'Poulet Breton',
        'Poulet Grillé',
        'Side Salad',
        'Smoked Haddock and Salmon Fishcakes',

    ];



    /**
     * perform some maintenance during deployment
     */
    public static function run()
    {
        foreach (static::$products as $name) {
            $productName = '[NOT FOR SALE] ' . $name;

            $posts = get_posts([
                'title'       => $productName,
                'post_status' => 'publish',
                'post_type'   => 'product',
                'fields'      => 'ids',
            ]);

            if (empty($posts)) {
                $product = new \WC_Product_Simple();
                $product->set_name($productName);
                $product->set_status('publish');
                $product->save();
                $product_id = $product->get_id();
            } else {
                $product_id = $posts[0];
            }

            update_field('field_product_not_for_sale', 1, $product_id);

        }

        $pcs = ProductComponent::get();
        foreach ($pcs as $pc) {
            $pc->delete();
        }


        $components = unserialize(static::$components);

        foreach ($components as $slug => $productComponents) {


            $product_id = Product::findIdBySlug($slug);

            $data = [];
            foreach ($productComponents as $component) {


                $component_id = Product::findIdBySlug($component['slug']);

                $data[] = [
                    'product_id' => $component_id,
                    'quantity'   => $component['quantity'],
                ];

            }

            $pc = new ProductComponent();
            $pc->product_id = [$product_id];
            $pc->components = $data;
            $pc->save();

        }

        return "Not for sale products created";
    }

}