<?php

namespace CoteAtHome\Releases;

use CoteAtHome\Abstracts\Release;

/**
 * Class clean
 *
 * @package CoteAtHome\Releases
 */
class ChangeCouponCodesToUppercase extends Release
{


    /**
     * perform some maintenance during deployment
     */
    public static function run()
    {
        global $wpdb;
        $wpdb->query("update wp_posts set post_title = upper(post_title) where post_type = 'shop_coupon'");

        return "Coupons changed to uppercase";
    }

}