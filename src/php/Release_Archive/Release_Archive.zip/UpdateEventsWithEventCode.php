<?php

namespace CoteAtHome\Releases;

use CoteAtHome\Abstracts\Release;
use CoteAtHome\Exceptions\CoteAtHomeException;
use CoteAtHome\Objects\Order;
use CoteAtHome\WooCommerce;

/**
 * Class clean
 *
 * @package CoteAtHome\Releases
 */
class UpdateEventsWithEventCode extends Release
{


    public static $runOnce = true;


    /**
     * perform some maintenance during deployment
     */
    public static function run()
    {

        global $wpdb;

        $results = $wpdb->get_results("SELECT order_id from wp_shop_sessions where coupons like '%EV-%' and status  ='Paid' ");

        foreach ($results as $result) {

            try {
                Order::find($result->order_id)->maybe_assign_to_an_event();
            } catch (CoteAtHomeException $e) {
                continue;
            }

        }

        return "Updated Event Orders";
    }

}